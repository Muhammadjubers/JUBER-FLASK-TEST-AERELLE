#include <stdio.h>

int main() {
    int num,i,j,temp;
    scanf("%d",&num);
    int a[num];
    for(i=0;i<num;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<num-1;i++){
    for(j=0;j<num-i-1;j++){
            if(a[j]>a[j+1]){
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
    }
    
    for(j=0;j<num;j++){
        printf("%d  ",a[j]);
        
    }
}
